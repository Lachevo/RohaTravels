import React from 'react';
import { Link } from 'react-router-dom';
import Navbar from './Navbar';

const Header = ({ isAmharic, toggleLanguage }) => {
  return (
    <header className="bg-[#294050] text-[#C8DDD8] p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="text-3xl font-bold">
          {" "}
          {/* Increased font size */}
          <span className="md:hidden">{isAmharic ? "ሮሃ" : "Roha"}</span>
          <span className="hidden md:inline">
            {isAmharic ? "ሮሃ ጉዞና ቱሪዝም" : "Roha Tour and Travel"}
          </span>
        </Link>
        <Navbar isAmharic={isAmharic} toggleLanguage={toggleLanguage} />
      </div>
    </header>
  );
};

export default Header;
