import React from 'react';
import { Link } from 'react-router-dom';
import { FacebookIcon, InstagramIcon } from 'lucide-react';

const Footer = ({ isAmharic }) => {
  const resources = [
    { title: isAmharic ? 'የጉዞ ምክሮች' : 'Travel Tips', link: '/travel-tips' },
    { title: isAmharic ? 'የጉዞ መመሪያ' : 'Travel Guide', link: '/travel-guide' },
    { title: isAmharic ? 'ብዙ የሚጠየቁ ጥያቄዎች' : 'FAQs', link: '/faqs' },
    { title: isAmharic ? 'ማህደር' : 'Gallery', link: '/gallery' },
  ];

  return (
    <footer className="bg-[#294050] text-[#C8DDD8] py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">
              {isAmharic ? "ሮሃ ጉዞና ቱሪዝም" : "Roha Tour and Travel"}
            </h3>
            <p>
              {isAmharic
                ? "የእርስዎ የተሟላ የጉዞ አጋር"
                : "Your Complete Travel Partner"}
            </p>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">
              {isAmharic ? "ያግኙን" : "Contact Us"}
            </h4>
            <p>
              <a
                href="mailto:info@roha-travels.com"
                className="hover:underline"
              >
                Email: info@roha-travels.com
              </a>
            </p>
            <p>
              <a href="tel:+251911611111" className="hover:underline">
                {isAmharic ? "ስልክ" : "Phone"}: +251-91-161-1111
              </a>
            </p>
            <p>
              <a href="tel:+251911888666" className="hover:underline">
                {isAmharic ? "ስልክ" : "Phone"}: +251-91-188-8666
              </a>
            </p>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">
              {isAmharic ? "ሀብቶች" : "Resources"}
            </h4>
            <ul>
              {resources.map((resource, index) => (
                <li key={index} className="mb-2">
                  <Link to={resource.link} className="hover:underline">
                    {resource.title}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">
              {isAmharic ? "ተከተሉን" : "Follow Us"}
            </h4>
            <div className="flex space-x-4">
              <a
                href="https://www.facebook.com/ROHAPLC?mibextid=LQQJ4d"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:opacity-80"
              >
                <FacebookIcon />
              </a>
              <a
                href="https://www.instagram.com/roha_travels?igsh=anFkN2dsc3Z6cWg%3D&utm_source=qr"
                target="_blank"
                rel="noopener noreferrer"
                className="hover:opacity-80"
              >
                <InstagramIcon />
              </a>
            </div>
          </div>
        </div>
        <div className="mt-8 text-center">
          <p>
            &copy; 2024 Roha Tour and Travel.{" "}
            {isAmharic ? "መብቱ በህግ የተጠበቀ ነው።" : "All rights reserved."}
          </p>
          <p className="mt-2">
            <a
              href="https://t.me/keneanalemayhu"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:underline"
            >
              {isAmharic ? "ከነአን አለማየሁ" : "Kenean Alemayhu"}
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
