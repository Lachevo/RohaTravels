import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const PopularTours = ({ isAmharic }) => {
  const content = {
    popularTours: isAmharic ? "ታዋቂ ጉዞዎች" : "Popular Tours",
    popularToursList: [
      {
        name: isAmharic ? "የታሪካዊ ጉዞ" : "Historical Tour",
        image: "https://images.unsplash.com/photo-1540541338287-41700207dee6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80",
        duration: "8 days",
      },
      {
        name: isAmharic ? "የተፈጥሮ ጉዞ" : "Nature Tour",
        image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1468&q=80",
        duration: "7 days",
      },
      {
        name: isAmharic ? "የባህል ጉዞ" : "Cultural Tour",
        image: "https://images.unsplash.com/photo-1523805009345-7448845a9e53?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1472&q=80",
        duration: "10 days",
      },
    ],
  };

  return (
    <div className="container mx-auto px-4 py-16">
      <h2 className="text-3xl font-bold mb-8 text-center text-[#28424F]">
        {content.popularTours}
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {content.popularToursList.map((tour, index) => (
          <Card key={index} className="overflow-hidden">
            <img
              src={tour.image}
              alt={tour.name}
              className="w-full h-48 object-cover"
            />
            <CardContent className="p-4">
              <h3 className="text-xl font-semibold mb-2">{tour.name}</h3>
              <p>{tour.duration}</p>
              <Button className="mt-4 w-full bg-[#C6DAD9] text-[#28424F] hover:bg-[#A8C5C4]">
                {isAmharic ? "ዝርዝር" : "Details"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default PopularTours;